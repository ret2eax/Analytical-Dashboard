from django.apps import AppConfig


class CmcDashboardConfig(AppConfig):
    name = 'cmc_dashboard'
